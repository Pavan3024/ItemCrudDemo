﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using SampleCRUDDemo.Models;

public interface IItemMasterRepository
{
    List<ItemViewModel> SelectItem();
    void ItemAdd(ItemViewModel item);
    ItemViewModel ItemUpdate(int id);
    void ItemUpdate(ItemViewModel item);
    void ItemDelete(int id);

}