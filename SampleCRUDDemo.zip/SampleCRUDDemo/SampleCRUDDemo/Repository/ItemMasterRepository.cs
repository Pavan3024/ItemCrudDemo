﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using SampleCRUDDemo.Models;
using static ItemMasterRepository;
using System;

public class ItemMasterRepository  : IItemMasterRepository
{
    public readonly ApplicationDbContext _context;

    public ItemMasterRepository(ApplicationDbContext context)
    {
        _context = context;
    }
 
    public List<ItemViewModel> SelectItem()
    {
        var ItemList = _context.itemmaster.OrderBy(item => item.item_id).ToList();
        return ItemList;
    }

    public void ItemAdd(ItemViewModel item)
    {
        _context.itemmaster.Add(item);
        _context.SaveChanges();
    }


    public ItemViewModel ItemUpdate(int id)
    {
        var itemDetails = _context.itemmaster.Find(id);
        return itemDetails;
    }


    public void ItemUpdate(ItemViewModel item)
    {
      _context.itemmaster.Update(item);
      _context.SaveChanges();
    }

    public void ItemDelete(int id)
    {
        var item = ItemUpdate(id);
        _context.itemmaster.Remove(item);
       _context.SaveChanges();
    }
    }

  


