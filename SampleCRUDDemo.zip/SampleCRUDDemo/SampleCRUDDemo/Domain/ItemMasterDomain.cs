﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SampleCRUDDemo.Models;

public class ItemMasterDomain: IItemMasterDomain
{
    public IItemMasterRepository _itemMasterRepository { get; set; }
    public ItemMasterDomain(IItemMasterRepository itemMasterRepository)
    {
        _itemMasterRepository = itemMasterRepository;
    }
    public List<ItemViewModel> SelectItem()
    {
        return _itemMasterRepository.SelectItem();
    }
    public void ItemAdd(ItemViewModel item)
    {
         _itemMasterRepository.ItemAdd(item);
    }

    public ItemViewModel ItemUpdate(int id)
    {
        return _itemMasterRepository.ItemUpdate(id);

    }
    public void ItemUpdate(ItemViewModel item)
    {
          _itemMasterRepository.ItemUpdate(item);
    }

    public void ItemDelete(int id)
    {
          _itemMasterRepository.ItemDelete(id);
    }
}