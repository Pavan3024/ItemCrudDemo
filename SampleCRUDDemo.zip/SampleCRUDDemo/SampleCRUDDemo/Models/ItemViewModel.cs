﻿using SampleCRUDDemo.Models;
using System.ComponentModel.DataAnnotations;

namespace SampleCRUDDemo.Models
{
    public class ItemViewModel
    {
        [Key]
        public int item_id { get; set; }
            
        public string? item_name { get; set; }

        public string? item_description { get; set; }

        public string? item_category { get; set; }

    }

}
