﻿using Microsoft.EntityFrameworkCore;
namespace SampleCRUDDemo.Models

{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext()
        {
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<ItemViewModel> itemmaster { get; set; }
    }

}
