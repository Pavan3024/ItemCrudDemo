﻿using Microsoft.AspNetCore.Mvc;
using NuGet.Protocol.Plugins;
using System;
using SampleCRUDDemo.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
 
namespace SampleCRUDDemo.Controllers
{
    public class ItemMasterController : Controller
    {
        public readonly ApplicationDbContext _context;
        public IItemMasterDomain _itemMasterDomain { get; set; }

        public ItemMasterController(ApplicationDbContext context, IItemMasterDomain itemMasterDomain)
        {
            _context = context;
            _itemMasterDomain = itemMasterDomain;
        }


        public IActionResult SelectItem()
        {            
            return View(_itemMasterDomain.SelectItem());
        }


        public IActionResult InsertItem()
        {
            List<string> categories = new List<string>()
            {
                "Clothing",
                "Personal Hygiene",
                "Technology",
                "Transportation"
            };
            ViewBag.Categories = new SelectList(categories,"item_category");
            return View();
        }


        [HttpPost]
        public IActionResult InsertItem(ItemViewModel item)
        {
            try
            {
                _itemMasterDomain.ItemAdd(item);
                return RedirectToAction("SelectItem");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");

            }

        }

        public IActionResult UpdateItem(int id)
        {
            List<string> categories = new List<string>()
            {
                "Clothing",
                "Personal Hygiene",
                "Technology",
                "Transportation"
            };

            ViewBag.Categories = new SelectList(categories, "item_category");
            var itemDetails = _context.itemmaster.Find(id);
            if (itemDetails == null)
            {
                return NotFound("Record not found");
            }
            return View(itemDetails);

        }

        [HttpPost]
        public IActionResult UpdateItem(ItemViewModel item)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _context.Entry(item).State = EntityState.Modified;
                    _itemMasterDomain.ItemUpdate(item);
                    return RedirectToAction("SelectItem");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }

            return View(item);
        }

         public IActionResult DeleteItem(int id)
      {
            try
            {
                var itemdata = _context.itemmaster.Find(id);
                if (itemdata == null)
                {
                    return NotFound("Record not found");
                }
                _itemMasterDomain.ItemDelete(id);
                return RedirectToAction("SelectItem");
            }
             catch(Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");

            }
        }

    }
}
